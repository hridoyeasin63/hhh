import express from "express";
import { createServer as createViteServer } from "vite";
import admin from "firebase-admin";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

import { getFirestore } from "firebase-admin/firestore";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const config = JSON.parse(fs.readFileSync(path.join(__dirname, "firebase-applet-config.json"), "utf8"));

// Initialize Firebase Admin
try {
  // Use the explicit project ID from config to avoid audience mismatch errors
  admin.initializeApp({
    projectId: config.projectId,
  });
  console.log(`Firebase Admin initialized for project: ${config.projectId}`);
} catch (err: any) {
  if (err.code !== "app/duplicate-app") {
    console.error("Firebase Admin initialization error:", err);
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Account Deletion
  app.post("/api/delete-account", async (req, res) => {
    const { userId } = req.body;
    const authHeader = req.headers.authorization;

    if (!userId || !authHeader) {
      return res.status(400).json({ error: "User ID and Authorization are required" });
    }

    try {
      const idToken = authHeader.replace("Bearer ", "");
      console.log(`Starting account deletion for UID: ${userId}`);
      
      // Verify the user is who they say they are
      const decodedToken = await admin.auth().verifyIdToken(idToken);
      
      if (decodedToken.uid !== userId) {
        console.warn(`UID mismatch: token=${decodedToken.uid}, requested=${userId}`);
        return res.status(403).json({ error: "Forbidden: UID mismatch" });
      }

      // Use the specific database if provided, otherwise default
      const dbId = config.firestoreDatabaseId;
      console.log(`Using database ID: ${dbId || '(default)'}`);
      
      let db: admin.firestore.Firestore;
      try {
        db = getFirestore(dbId);
      } catch (err) {
        console.warn("Failed to get Firestore for specific ID, checking default:", err);
        db = getFirestore();
      }

      // Helper function to query with fallback and swallow errors if necessary
      async function findUserDocs(collectionName: string) {
        try {
          return await db.collection(collectionName).where("user_id", "==", userId).get();
        } catch (err: any) {
          console.warn(`Query failed for ${collectionName} in DB ${dbId || 'default'}:`, err.message);
          
          // Try default DB as absolute last resort if not already using it
          if (dbId) {
            try {
              console.log(`Attempting fallback to default database for ${collectionName}...`);
              return await getFirestore().collection(collectionName).where("user_id", "==", userId).get();
            } catch (fallbackErr: any) {
              console.warn(`Fallback also failed for ${collectionName}:`, fallbackErr.message);
            }
          }
          
          // Return empty result instead of crashing if we can't search
          return { empty: true, docs: [] } as any;
        }
      }

      // 1. Delete Firestore Data (Best effort)
      const collections = ["ot_records", "salary_settings"];
      for (const col of collections) {
        const snapshot = await findUserDocs(col);
        if (snapshot && !snapshot.empty) {
          console.log(`Deleting ${snapshot.docs.length} docs from ${col}`);
          const batch = db.batch();
          snapshot.docs.forEach((doc) => batch.delete(doc.ref));
          await batch.commit().catch(e => console.warn(`Batch delete failed for ${col}:`, e.message));
        }
      }

      // 2. Delete Auth User
      try {
        await admin.auth().deleteUser(userId);
        console.log("Auth user deleted");
      } catch (err: any) {
        // If user already deleted, that's fine
        if (err.code === "auth/user-not-found" || err.code === 5 || (err.message && err.message.includes("NOT_FOUND"))) {
          console.log("Auth user not found or already deleted");
        } else {
          throw err;
        }
      }

      res.json({ message: "Account successfully deleted" });
    } catch (err: any) {
      console.error("Account deletion failed:", err);
      res.status(500).json({ error: err.message || "Internal server error" });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
