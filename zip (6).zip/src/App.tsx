import { useEffect, useState } from 'react';
import { auth } from './lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import Auth from './components/Auth';
import OTCalculator from './components/OTCalculator';
import { Menu, Download } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [showInfo, setShowInfo] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-linear-to-br from-[#4facfe] to-[#00f2fe]">
        <div className="text-white text-xl animate-pulse font-medium">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-linear-to-br from-[#4facfe] to-[#00f2fe] p-4 flex flex-col items-center">
      {!user ? (
        <Auth />
      ) : (
        <div className="w-full max-w-sm">
          <div className="flex justify-between items-center mb-2 px-1">
            <span className="text-[10px] font-black text-white bg-slate-900 px-3 py-1 rounded-full uppercase tracking-[0.2em] border border-white/10 shadow-sm">Hridoy Hasan Yeasin</span>
            <a 
              href="https://drive.google.com/file/d/1vXggfP3tKCAkbO4sMcwPj_O2Tcrqfaab/view?usp=sharing" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-[9px] font-black bg-white/20 hover:bg-white/30 text-white px-3 py-1 rounded-full transition-all border border-white/10 shadow-sm uppercase tracking-wider"
            >
              <Download size={12} /> App
            </a>
            <button
              onClick={() => setShowInfo(true)}
              className="flex items-center gap-1 text-xs bg-white/20 hover:bg-white/30 text-white p-2 rounded-full transition-colors shadow-sm"
            >
              <Menu size={16} />
            </button>
          </div>
          <OTCalculator user={user} showInfo={showInfo} setShowInfo={setShowInfo} />
        </div>
      )}
    </div>
  );
}
