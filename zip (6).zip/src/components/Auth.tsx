import { auth } from '../lib/firebase';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  updateProfile,
  sendEmailVerification,
  sendPasswordResetEmail
} from 'firebase/auth';
import { LogIn, UserPlus, Mail, Lock, User as UserIcon, Loader2, KeyRound, Download } from 'lucide-react';
import { useState, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export default function Auth() {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError('');
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      console.error("Login failed:", error);
      setError(error.message || "Login failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    if (!email) {
      setError("পাসওয়ার্ড রিসেট করতে আগে আপনার ইমেলটি লিখুন।");
      return;
    }
    
    setLoading(true);
    setError('');
    try {
      await sendPasswordResetEmail(auth, email);
      setError("আপনার ইমেলে পাসওয়ার্ড রিসেট লিঙ্ক পাঠানো হয়েছে। চেক করুন!");
    } catch (error: any) {
      console.error("Password reset error:", error);
      setError("ইমেল পাঠাতে সমস্যা হয়েছে। সঠিক ইমেল দিয়েছেন কি না দেখুন।");
    } finally {
      setLoading(false);
    }
  };

  const handleEmailAuth = async (e: FormEvent) => {
    e.preventDefault();
    if (!email || !password || (isSignUp && !name)) {
      setError("Please fill all fields.");
      return;
    }
    
    setLoading(true);
    setError('');
    
    const trimmedEmail = email.trim().toLowerCase();
    const trimmedPassword = password.trim();
    
    try {
      if (isSignUp) {
        const userCredential = await createUserWithEmailAndPassword(auth, trimmedEmail, trimmedPassword);
        await updateProfile(userCredential.user, {
          displayName: name
        });
        await sendEmailVerification(userCredential.user);
        setError("ভেরিফিকেশন ইমেল পাঠানো হয়েছে! লগইন করার আগে আপনার ইনবক্স চেক করুন এবং ইমেল ভেরিফাই করুন।");
      } else {
        await signInWithEmailAndPassword(auth, trimmedEmail, trimmedPassword);
      }
    } catch (error: any) {
      console.error("Authentication Detailed Error:", {
        code: error.code,
        message: error.message,
        email: trimmedEmail
      });
      
      let msg = "";
      // Unified error code for 'user-not-found' and 'wrong-password' when enumeration protection is enabled
      if (error.code === 'auth/invalid-credential') {
        msg = "ইমেল অথবা পাসওয়ার্ড ভুল। আপনি কি সঠিক ইমেল দিয়েছেন? আপনার যদি অ্যাকাউন্ট না থাকে তবে উপরে Sign Up-এ ক্লিক করে নতুন অ্যাকাউন্ট তৈরি করুন।";
      } else if (error.code === 'auth/email-already-in-use') {
        msg = "এই ইমেলটি ইতিমধ্যে ব্যবহার করা হয়েছে। সাইন ইন করার চেষ্টা করুন।";
      } else if (error.code === 'auth/invalid-email') {
        msg = "ইমেল এড্রেসটি সঠিক নয়। অনুগ্রহ করে সঠিক ইমেল দিন।";
      } else if (error.code === 'auth/weak-password') {
        msg = "পাসওয়ার্ড অন্তত ৬ অক্ষরের হতে হবে।";
      } else if (error.code === 'auth/too-many-requests') {
        msg = "অনেকবার ভুল চেষ্টা করা হয়েছে। আপনার অ্যাকাউন্ট সাময়িকভাবে ব্লক করা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন অথবা পাসওয়ার্ড রিসেট করুন।";
      } else if (error.code === 'auth/operation-not-allowed') {
        msg = "এই লগইন মাধ্যমটি সক্রিয় নয়। অনুগ্রহ করে অ্যাডমিনের সাথে যোগাযোগ করুন।";
      } else {
        msg = `সমস্যা হয়েছে: ${error.message}`;
      }
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white p-8 rounded-[2rem] shadow-2xl w-full max-w-sm text-center relative overflow-hidden border border-slate-100"
    >
      {/* Background Accent */}
      <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-teal-400 via-emerald-500 to-teal-600"></div>
      
      <h1 className="text-3xl font-black text-slate-800 mb-1 italic tracking-tighter">OT Manager Pro</h1>
      <p className="text-xs font-bold text-teal-600 uppercase tracking-[0.2em] mb-6">Hridoy Hasan Yeasin</p>
      
      <a 
        href="https://drive.google.com/file/d/1vXggfP3tKCAkbO4sMcwPj_O2Tcrqfaab/view?usp=sharing" 
        target="_blank" 
        rel="noopener noreferrer"
        className="mb-6 w-full flex items-center justify-center gap-2 bg-teal-50 text-teal-600 px-6 py-3 rounded-xl hover:bg-teal-100 transition-all font-bold text-[11px] uppercase tracking-wider border border-teal-100 shadow-sm"
      >
        <Download size={14} /> Download Mobile App
      </a>

      <div className="flex bg-slate-100 p-1 rounded-2xl mb-6">
        <button 
          onClick={() => setIsSignUp(false)}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${!isSignUp ? 'bg-white shadow-sm text-slate-800' : 'text-slate-400'}`}
        >
          Sign In
        </button>
        <button 
          onClick={() => setIsSignUp(true)}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${isSignUp ? 'bg-white shadow-sm text-slate-800' : 'text-slate-400'}`}
        >
          Sign Up
        </button>
      </div>

      <AnimatePresence mode="wait">
        <motion.form 
          key={isSignUp ? 'signup' : 'signin'}
          initial={{ opacity: 0, x: isSignUp ? 20 : -20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: isSignUp ? -20 : 20 }}
          transition={{ duration: 0.2 }}
          onSubmit={handleEmailAuth} 
          className="space-y-4"
        >
          {isSignUp && (
            <div className="relative">
              <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input 
                type="text" 
                placeholder="Full Name" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:border-teal-500 outline-none transition-all font-medium"
              />
            </div>
          )}
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input 
              type="email" 
              placeholder="Email Address" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:border-teal-500 outline-none transition-all font-medium"
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input 
              type="password" 
              placeholder="Password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:border-teal-500 outline-none transition-all font-medium"
            />
          </div>

          {!isSignUp && (
            <div className="flex justify-end">
              <button
                type="button"
                onClick={handleForgotPassword}
                className="text-[10px] font-bold text-teal-600 hover:text-teal-700 uppercase tracking-wider flex items-center gap-1"
              >
                <KeyRound size={12} />
                Forgot Password?
              </button>
            </div>
          )}

          {error && <p className="text-[10px] text-rose-500 font-bold text-left px-1 mt-1">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-slate-800 text-white py-3 rounded-xl font-bold text-sm hover:bg-slate-900 transition-all shadow-lg active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center gap-2"
          >
            {loading ? <Loader2 className="animate-spin" size={18} /> : (isSignUp ? <UserPlus size={18} /> : <LogIn size={18} />)}
            {isSignUp ? 'Create Account' : 'Sign In'}
          </button>
        </motion.form>
      </AnimatePresence>

      <div className="flex items-center my-6">
        <div className="flex-1 h-px bg-slate-100"></div>
        <span className="px-3 text-[10px] font-bold text-slate-300 uppercase">OR</span>
        <div className="flex-1 h-px bg-slate-100"></div>
      </div>

      <button
        onClick={handleGoogleLogin}
        disabled={loading}
        className="w-full flex items-center justify-center gap-3 bg-white border border-slate-200 text-slate-600 px-6 py-3 rounded-xl hover:bg-slate-50 transition-all shadow-sm font-bold text-sm disabled:opacity-50"
      >
        <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
        Continue with Google
      </button>

      <p className="text-[10px] text-slate-400 mt-6 font-medium">
        Secure access to your OT records across any device.
      </p>
    </motion.div>
  );
}
