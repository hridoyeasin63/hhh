import { useState, useEffect, useCallback, ChangeEvent } from 'react';
import { db, auth } from '../lib/firebase';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  doc, 
  setDoc, 
  deleteDoc, 
  getDoc,
  serverTimestamp,
  getDocs,
  writeBatch
} from 'firebase/firestore';
import { signOut, User, EmailAuthProvider, reauthenticateWithCredential, updatePassword, GoogleAuthProvider, reauthenticateWithPopup } from 'firebase/auth';
import { motion, AnimatePresence } from 'motion/react';
import { Info, Plus, Edit2, Save, Trash2, X, Download, Upload, Facebook, Twitter, MessageCircle, LogOut, Lock } from 'lucide-react';

interface OTData {
  [key: string]: number | 'holiday' | 'absent';
}

interface SalarySettings {
  salary: number;
  rate: number;
  bonus: number;
  advance: number;
}

const dayNames = ["রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"];
const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

// Converts user format (H.MM) to true decimal hours (e.g., 2.5 -> 2.833, 1.30 -> 1.5)
const toRealHours = (val: number): number => {
  const h = Math.floor(val);
  const m = Math.round((val - h) * 100);
  return h + (m / 60);
};

// Converts true decimal hours to user format (H.MM)
const toUserFormat = (realHours: number): number => {
  const totalMinutes = Math.round(realHours * 60);
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  return h + (m / 100);
};

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export default function OTCalculator({ user, showInfo, setShowInfo }: { user: User; showInfo: boolean; setShowInfo: (val: boolean) => void }) {
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth());
  const [day, setDay] = useState(new Date().getDate());
  const [otInput, setOtInput] = useState("");
  
  const [otData, setOtData] = useState<OTData>({});
  const [settings, setSettings] = useState<SalarySettings>({ salary: 0, rate: 0, bonus: 0, advance: 0 });
  const [modal, setModal] = useState<{ title: string; text: string; value: string; callback: (val: string) => void; type: string } | null>(null);
  const [showProfile, setShowProfile] = useState(false);

  // Month key for settings YYYY-M
  const getMonthKey = () => `${year}-${month + 1}`;
  
  // Real-time sync for settings
  useEffect(() => {
    const key = getMonthKey();
    const docId = `${user.uid}_${key}`;
    const docRef = doc(db, 'salary_settings', docId);

    const unsubscribe = onSnapshot(docRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        const salary = data.salary || 0;
        // Calculated rate: (salary - 2450) / (1.5 * 104)
        const calculatedRate = salary > 2450 ? parseFloat(((salary - 2450) / (1.5 * 104)).toFixed(2)) : 0;
        
        setSettings({
          salary: salary,
          rate: calculatedRate,
          bonus: data.bonus || 0,
          advance: data.advance || 0
        });
      } else {
        setSettings({ salary: 0, rate: 0, bonus: 0, advance: 0 });
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `salary_settings/${docId}`);
    });

    return () => unsubscribe();
  }, [user.uid, year, month]);

  // Real-time sync for overtime data
  useEffect(() => {
    const q = query(
      collection(db, 'ot_records'),
      where('user_id', '==', user.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const mappedData: OTData = {};
      snapshot.forEach((doc) => {
        const record = doc.data();
        if (record.value === 'holiday') mappedData[record.date_key] = 'holiday';
        else if (record.value === 'absent') mappedData[record.date_key] = 'absent';
        else mappedData[record.date_key] = parseFloat(record.value);
      });
      setOtData(mappedData);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'ot_records');
    });

    return () => unsubscribe();
  }, [user.uid]);

  const saveOT = async (dateKey: string, value: number | 'holiday' | 'absent' | null) => {
    const docId = `${user.uid}_${dateKey}`;
    const docRef = doc(db, 'ot_records', docId);

    try {
      if (value === null) {
        await deleteDoc(docRef);
      } else {
        await setDoc(docRef, {
          user_id: user.uid,
          date_key: dateKey,
          value: value.toString(),
          updated_at: serverTimestamp()
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `ot_records/${docId}`);
    }
  };

  const saveSettings = async (newSettings: Partial<SalarySettings>) => {
    const key = getMonthKey();
    const docId = `${user.uid}_${key}`;
    const docRef = doc(db, 'salary_settings', docId);

    try {
      await setDoc(docRef, {
        user_id: user.uid,
        month_key: key,
        ...settings,
        ...newSettings,
        updated_at: serverTimestamp()
      }, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `salary_settings/${docId}`);
    }
  };

  const handleAddOT = () => {
    const key = `${year}-${month + 1}-${day}`;
    const val = otInput.trim();
    
    if (val === "000") {
      saveOT(key, "absent");
    } else if (val === "0000") {
      saveOT(key, "holiday");
    } else if (val !== "") {
      const num = parseFloat(val);
      if (!isNaN(num) && num >= 0) {
        const normalizedNum = toUserFormat(toRealHours(num));
        const real = toRealHours(normalizedNum);
        if (real <= 9) {
          saveOT(key, normalizedNum); // Store normalized user format in DB
        } else {
          setModal({
            title: "Warning",
            text: "Maximum OT is 9 hours!",
            value: "",
            callback: () => {},
            type: "alert"
          });
          return;
        }
      } else {
        return;
      }
    } else {
      return;
    }

    setOtInput("");
    // Move to next day logic
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    if (day < daysInMonth) {
      setDay(day + 1);
    } else {
      if (month < 11) {
        setMonth(month + 1);
        setDay(1);
      } else {
        setYear(year + 1);
        setMonth(0);
        setDay(1);
      }
    }
  };

  const calcOTValues = (otUser: number, dayOfWeek: number) => {
    const ot = toRealHours(otUser);
    let got = 0, eot = 0;
    if (dayOfWeek === 5) { // Friday
      eot = ot;
    } else {
      if (ot <= 2) {
        got = ot;
      } else {
        got = 2;
        eot = ot - 2;
      }
    }
    return { 
      gotReal: got, 
      eotReal: eot, 
      gotUser: toUserFormat(got), 
      eotUser: toUserFormat(eot) 
    };
  };

  const handleDeleteRecord = (key: string) => {
    setModal({
      title: "Delete Record?",
      text: "আপনি কি এই ওটি রেকর্ডটি মুছে ফেলতে চান?",
      value: "",
      type: "confirm",
      callback: () => saveOT(key, null)
    });
  };

  const renderRows = () => {
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const rows = [];
    let totalOT = 0, totalGOT = 0, totalEOT = 0;
    let totalFridays = 0;
    let absentDays = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (let d = 1; d <= daysInMonth; d++) {
      const date = new Date(year, month, d);
      date.setHours(0, 0, 0, 0);
      const key = `${year}-${month + 1}-${d}`;
      const ot = otData[key];
      const isToday = d === today.getDate() && month === today.getMonth() && year === today.getFullYear();
      const isFuture = date > today;
      const isFriday = date.getDay() === 5;
      
      if (isFriday) totalFridays++;

      let content;
      if (ot === "absent") {
        absentDays++;
        content = (
          <td colSpan={3} className="text-slate-400 font-bold bg-slate-100/50 py-1.5 text-[11px] text-center">অনুপস্থিত</td>
        );
      } else if (ot === "holiday" || (isFriday && ot === undefined)) {
        content = (
          <td colSpan={3} className="text-rose-500 font-bold bg-rose-50/50 py-1.5 text-[11px] text-center">ছুটির দিন</td>
        );
      } else if (ot !== undefined && typeof ot === 'number') {
        const { gotReal, eotReal, gotUser, eotUser } = calcOTValues(ot, date.getDay());
        totalOT += toRealHours(ot);
        totalGOT += gotReal;
        totalEOT += eotReal;
        content = (
          <>
            <td className="p-1 px-2 cursor-pointer hover:bg-teal-50 font-mono text-[14px] font-bold" onClick={() => openEditModal(key, ot)}>
              {ot.toFixed(2).replace(/\.00$/, '')}
            </td>
            <td className="p-1 px-2 font-mono text-[14px] text-slate-700 font-medium">{gotUser.toFixed(2).replace(/\.00$/, '')}</td>
            <td className="p-1 px-2 font-mono text-[14px] text-slate-700 font-medium">{eotUser.toFixed(2).replace(/\.00$/, '')}</td>
          </>
        );
      } else {
        const value = isFuture ? "" : "0";
        content = (
          <>
            <td className="p-1 px-2 font-mono text-[14px] text-slate-400">{value}</td>
            <td className="p-1 px-2 font-mono text-[14px] text-slate-400">{value}</td>
            <td className="p-1 px-2 font-mono text-[14px] text-slate-400">{value}</td>
          </>
        );
      }

      // Long press handling
      let timer: any;
      const handleTouchStart = () => {
        if (isFriday && (ot === undefined || ot === 'holiday')) return; // Can't delete Friday holiday
        if (ot === undefined) return;
        timer = setTimeout(() => handleDeleteRecord(key), 800);
      };
      const handleTouchEnd = () => clearTimeout(timer);

      rows.push(
        <tr 
          key={d} 
          onPointerDown={handleTouchStart}
          onPointerUp={handleTouchEnd}
          onPointerLeave={handleTouchEnd}
          onContextMenu={(e) => e.preventDefault()}
          className={`border-b border-slate-50 text-center transition-colors transition-duration-300 select-none ${isToday ? 'bg-teal-50/50 border-b-2 border-teal-500' : 'hover:bg-slate-50/30'}`}
        >
          <td className="p-1 px-2 text-[15px] font-bold text-slate-500">{d < 10 ? `0${d}` : d}</td>
          <td className="p-1 px-2 text-[13px] text-slate-600 font-bold uppercase tracking-tighter">{dayNames[date.getDay()]}</td>
          {content}
        </tr>
      );
    }

    return { rows, totalOT, totalGOT, totalEOT, totalFridays, absentDays, daysInMonth };
  };

  const openEditModal = (key: string, current: number | 'holiday' | 'absent') => {
    setModal({
      title: "ওটি পরিবর্তন",
      text: "পয়েন্টের পরের অংশ মিনিট (যেমন ১.৩০ = ১ ঘন্টা ৩০ মিনিট)। ০০০ = অনুপস্থিত, ০০০০ = ছুটি",
      value: typeof current === 'number' ? current.toFixed(2).replace(/\.00$/, '') : "",
      type: "text",
      callback: (val) => {
        if (val === "000") saveOT(key, "absent");
        else if (val === "0000") saveOT(key, "holiday");
        else if (val === "") saveOT(key, null);
        else {
          const num = parseFloat(val);
          if (!isNaN(num) && num >= 0) {
            const normalizedNum = toUserFormat(toRealHours(num));
            const real = toRealHours(normalizedNum);
            if (real <= 9) {
              saveOT(key, normalizedNum);
            } else {
              setModal({
                title: "Warning",
                text: "Maximum OT is 9 hours!",
                value: "",
                callback: () => {},
                type: "alert"
              });
            }
          }
        }
      }
    });
  };

  const { rows, totalOT, totalGOT, totalEOT, totalFridays, absentDays, daysInMonth } = renderRows();

  const otSalary = Math.round(totalOT * settings.rate);
  const gotSalary = Math.round(totalGOT * settings.rate);
  const eotSalary = Math.round(totalEOT * settings.rate);
  
  // Absent deduction: ((Salary - 2450) / 1.5) / (Total Days - Total Fridays)
  const daysExcludingFridays = daysInMonth - totalFridays;
  const deductionPerDay = daysExcludingFridays > 0 ? ((settings.salary - 2450) / 1.5) / daysExcludingFridays : 0;
  const totalDeduction = Math.round(absentDays * deductionPerDay);

  // If absentDays > 0, bonus is fixed to 0
  const effectiveBonus = absentDays > 0 ? 0 : (settings.bonus || 0);

  const payslip = (settings.salary + effectiveBonus + gotSalary) - (settings.advance || 0) - totalDeduction;
  const finalSalary = payslip + eotSalary;
  const extraSalary = finalSalary - payslip;

  const backupData = () => {
    const data = {
      otData,
      settings
    };
    const blob = new Blob([JSON.stringify(data)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ot-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleRestore = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        
        if (json.settings) {
          await saveSettings(json.settings);
        }

        if (json.otData) {
          const promises = Object.entries(json.otData).map(([key, val]) => {
            return saveOT(key, val as number | 'holiday');
          });
          await Promise.all(promises);
          alert("Restore complete!");
        }
      } catch (err) {
        console.error("Restore failed:", err);
        alert("Invalid backup file.");
      }
    };
    reader.readAsText(file);
  };

  const handleUpdatePassword = async () => {
    const isPasswordUser = user.providerData.some(p => p.providerId === 'password');
    if (!isPasswordUser) {
      setModal({
        title: "Info",
        text: "আপনি সোশ্যাল মিডিয়া (Google) দিয়ে লগইন করেছেন। পাসওয়ার্ড পরিবর্তনের প্রয়োজন নেই।",
        value: "",
        type: "alert",
        callback: () => {}
      });
      return;
    }

    setModal({
      title: "বর্তমান পাসওয়ার্ড",
      text: "পাসওয়ার্ড পরিবর্তন করতে আগে বর্তমান পাসওয়ার্ডটি দিন।",
      value: "",
      type: "password",
      callback: async (currentPwd) => {
        if (!currentPwd) return;
        setModal(null);
        const trimmedPwd = currentPwd.trim();
        try {
          const currentUser = auth.currentUser;
          if (!currentUser || !currentUser.email) return;

          // Re-authenticate
          const credential = EmailAuthProvider.credential(currentUser.email, trimmedPwd);
          await reauthenticateWithCredential(currentUser, credential);
          
          // Now ask for new password
          setTimeout(() => {
            setModal({
              title: "নতুন পাসওয়ার্ড",
              text: "আপনার নতুন পাসওয়ার্ডটি লিখুন (কমপক্ষে ৬ অক্ষর)।",
              value: "",
              type: "password",
              callback: async (newPwd) => {
                if (newPwd.length < 6) {
                  alert("পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।");
                  return;
                }
                setModal(null);
                try {
                  await updatePassword(currentUser, newPwd);
                  setModal({
                    title: "সফল!",
                    text: "আপনার পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে।",
                    value: "",
                    type: "alert",
                    callback: () => {}
                  });
                } catch (updateErr: any) {
                  alert("পাসওয়ার্ড আপডেটে সমস্যা হয়েছে: " + updateErr.message);
                }
              }
            });
          }, 300);

        } catch (error: any) {
          console.error("Re-auth error:", error);
          alert("পাসওয়ার্ড ভুল অথবা সার্ভার সমস্যা।");
        }
      }
    });
  };

  const executeDeletion = async (currentUser: User) => {
    try {
      const recordsQuery = query(collection(db, 'ot_records'), where('user_id', '==', currentUser.uid));
      const settingsQuery = query(collection(db, 'salary_settings'), where('user_id', '==', currentUser.uid));
      
      const [recordsSnap, settingsSnap] = await Promise.all([
        getDocs(recordsQuery),
        getDocs(settingsQuery)
      ]);

      const batch = writeBatch(db);
      recordsSnap.forEach(doc => batch.delete(doc.ref));
      settingsSnap.forEach(doc => batch.delete(doc.ref));
      
      if (!recordsSnap.empty || !settingsSnap.empty) {
        await batch.commit();
      }

      await currentUser.delete();
    } catch (error: any) {
      console.error("Deletion process failed:", error);
      throw error;
    }
  };

  const handleDeleteAccount = async () => {
    const isPasswordUser = user.providerData.some(p => p.providerId === 'password');
    const isGoogleUser = user.providerData.some(p => p.providerId === 'google.com');

    if (isPasswordUser) {
      setModal({
        title: "পাসওয়ার্ড দিয়ে নিশ্চিত করুন",
        text: "অ্যাকাউন্ট ডিলেট করতে আপনার পাসওয়ার্ডটি লিখুন। এটি আপনার সমস্ত ডাটা স্থায়ীভাবে মুছে ফেলবে।",
        value: "",
        type: "password",
        callback: async (password) => {
          if (!password) return;
          const trimmedPwd = password.trim();
          setModal(null);
          try {
            const currentUser = auth.currentUser;
            if (!currentUser || !currentUser.email) return;

            const credential = EmailAuthProvider.credential(currentUser.email, trimmedPwd);
            await reauthenticateWithCredential(currentUser, credential);
            await executeDeletion(currentUser);
          } catch (error: any) {
            console.error("Re-auth/Deletion error:", error);
            let errorMessage = "অ্যাকাউন্ট ডিলেট করতে সমস্যা হয়েছে।";
            if (error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
              errorMessage = "পাসওয়ার্ড সঠিক নয়। দয়া করে সঠিক পাসওয়ার্ড দিন। যদি পাসওয়ার্ড ভুলে যান, লগআউট করে রিসেট করুন।";
            } else if (error.code === 'auth/requires-recent-login') {
              errorMessage = "নিরাপত্তার জন্য আবার লগইন প্রয়োজন। দয়া করে রিফ্রেশ করে আবার লগইন করুন।";
            }
            
            setModal({
              title: "Error",
              text: errorMessage,
              value: "",
              type: "alert",
              callback: () => {}
            });
          }
        }
      });
    } else if (isGoogleUser) {
      setModal({
        title: "অ্যাকাউন্ট মুছতে ইমেইল লিখুন",
        text: `নিশ্চিত করতে আপনার ইমেইল (${user.email}) টি নিচে লিখুন। এটি আপনার সমস্ত ডাটা স্থায়ীভাবে মুছে ফেলবে।`,
        value: "",
        type: "text",
        callback: async (inputEmail) => {
          if (!inputEmail) return;
          if (inputEmail.toLowerCase() !== user.email?.toLowerCase()) {
            setModal({
              title: "Wrong Email",
              text: "ইমেইল অ্যাড্রেসটি সঠিক নয়। দয়া করে আপনার সঠিক ইমেইলটি লিখুন।",
              value: "",
              type: "alert",
              callback: () => {}
            });
            return;
          }
          setModal(null);
          try {
            const currentUser = auth.currentUser;
            if (!currentUser) return;
            await executeDeletion(currentUser);
          } catch (error: any) {
            console.error("Deletion error:", error);
            if (error.code === 'auth/requires-recent-login') {
              setModal({
                title: "অ্যাকাউন্ট ভেরিফাই করতে হবে",
                text: "নিরাপত্তার কারণে আপনার গুগল অ্যাকাউন্টটি একবার ভেরিফাই করতে হবে। নিচের বাটনে ক্লিক করুন।",
                value: "",
                type: "confirm", // Using confirm type to show Re-verify button
                callback: async () => {
                  setModal(null);
                  try {
                    const currentUser = auth.currentUser;
                    if (!currentUser) return;
                    const provider = new GoogleAuthProvider();
                    await reauthenticateWithPopup(currentUser, provider);
                    // Try deleting again
                    await executeDeletion(currentUser);
                  } catch (reauthErr: any) {
                    alert("ভেরিফিকেশন ব্যর্থ হয়েছে। আবার চেষ্টা করুন।");
                  }
                }
              });
            } else {
              setModal({
                title: "Error",
                text: "অ্যাকাউন্ট ডিলেট করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।",
                value: "",
                type: "alert",
                callback: () => {}
              });
            }
          }
        }
      });
    } else {
      setModal({
        title: "অ্যাকাউন্ট ডিলেট করুন?",
        text: "আপনি কি নিশ্চিত? এটি আপনার সমস্ত ডাটা স্থায়ীভাবে মুছে ফেলবে।",
        value: "",
        type: "confirm",
        callback: async () => {
          setModal(null);
          try {
            const currentUser = auth.currentUser;
            if (!currentUser) return;
            await executeDeletion(currentUser);
          } catch (error: any) {
            setModal({
              title: "Error",
              text: "অ্যাকাউন্ট ডিলেট করতে সমস্যা হয়েছে। দয়া করে আবার লগইন করে চেষ্টা করুন।",
              value: "",
              type: "alert",
              callback: () => {}
            });
          }
        }
      });
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.15 }}
      className="bg-white rounded-xl shadow-sm p-4 relative border border-slate-200"
    >
      {/* {!user.emailVerified && (
        <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-3">
          <Info className="text-amber-500 shrink-0 mt-0.5" size={16} />
          <div className="flex-1">
            <p className="text-[11px] font-bold text-amber-800">Email Not Verified</p>
            <p className="text-[10px] text-amber-700 leading-tight">Please check your inbox and verify your email to enable saving records. Refresh the page after verifying.</p>
          </div>
        </div>
      )} */}

      <div className="flex items-center justify-between mb-4 bg-slate-50/50 p-2 rounded-2xl border border-slate-100">
        <div className="flex items-center gap-3 cursor-pointer hover:bg-slate-100/50 transition-colors rounded-xl p-1 pr-4" onClick={() => setShowProfile(true)}>
          {user.photoURL ? (
            <img src={user.photoURL} alt="Profile" className="w-10 h-10 rounded-full border-2 border-white shadow-sm" referrerPolicy="no-referrer" />
          ) : (
            <div className="w-10 h-10 rounded-full bg-teal-100 flex items-center justify-center text-teal-600 font-bold border-2 border-white shadow-sm">
              {(user.displayName || user.email)?.charAt(0) || 'U'}
            </div>
          )}
          <div className="flex flex-col">
            <h2 className="text-[13px] font-black text-slate-800 leading-tight uppercase">{user.displayName || 'User'}</h2>
            <p className="text-[9px] text-teal-600 font-bold lowercase tracking-wider truncate max-w-[150px]">{user.email}</p>
          </div>
        </div>
        <button 
          onClick={() => signOut(auth)}
          className="p-2 bg-white rounded-xl text-rose-400 hover:text-rose-600 transition border border-slate-100 shadow-sm"
          title="Sign Out"
        >
          <LogOut size={18} />
        </button>
      </div>

      <div className="flex gap-1 mb-3 items-center w-full px-0.5">
        <select value={year} onChange={(e) => setYear(parseInt(e.target.value))} className="p-1 px-2 border border-slate-200 rounded-md text-[11px] font-bold bg-white text-slate-600 outline-none focus:border-teal-500 min-w-0 flex-shrink">
          {[2025, 2026, 2027, 2028, 2029, 2030].map(y => <option key={y} value={y}>{y}</option>)}
        </select>
        <select value={month} onChange={(e) => setMonth(parseInt(e.target.value))} className="p-1 px-2 border border-slate-200 rounded-md text-[11px] font-bold bg-white text-slate-600 outline-none focus:border-teal-500 min-w-0 flex-shrink">
          {months.map((m, i) => <option key={i} value={i}>{m}</option>)}
        </select>
        <select value={day} onChange={(e) => setDay(parseInt(e.target.value))} className="p-1 px-2 border border-slate-200 rounded-md text-[11px] font-bold bg-white text-slate-600 outline-none focus:border-teal-500 min-w-0 flex-shrink">
          {Array.from({ length: new Date(year, month + 1, 0).getDate() }, (_, i) => i + 1).map(d => <option key={d} value={d}>{d}</option>)}
        </select>
        <input 
          type="text" 
          inputMode="decimal"
          value={otInput}
          onChange={(e) => setOtInput(e.target.value.replace(/[^0-9.]/g, '').slice(0, 5))}
          placeholder="Hour"
          className="flex-1 min-w-0 p-1 px-2 border border-slate-200 rounded-md text-center font-bold text-[11px] mono outline-none focus:border-teal-500"
        />
        <button 
          onClick={handleAddOT}
          className="bg-teal-600 text-white p-1 px-4 rounded-md font-bold text-[11px] hover:bg-teal-700 transition active:scale-95 whitespace-nowrap"
        >
          Add
        </button>
      </div>

      <div className="mb-4 border border-slate-100 rounded-lg shadow-inner bg-slate-50/20 no-scrollbar overflow-x-hidden">
        <table className="w-full text-sm border-collapse table-fixed">
              <thead className="bg-slate-100/50 backdrop-blur border-b border-slate-200">
                <tr className="text-slate-500 text-[13px] uppercase tracking-widest font-bold">
                  <th className="p-2 w-[15%]">DATE</th>
                  <th className="p-2 w-[22%]">DAY</th>
                  <th className="p-2 w-[20%]">OT</th>
                  <th className="p-2 w-[21%]">GOT</th>
                  <th className="p-2 w-[22%]">EOT</th>
                </tr>
              </thead>
          <tbody className="divide-y divide-slate-50">{rows}</tbody>
          <tfoot className="bg-teal-50/80 backdrop-blur font-bold border-t border-teal-100">
            <tr>
              <td colSpan={2} className="p-2 text-teal-800 text-[15px] uppercase">TOTAL</td>
              <td className="p-2 text-teal-800 mono text-[16px]">{toUserFormat(totalOT).toFixed(2).replace(/\.00$/, '')}</td>
              <td className="p-2 text-teal-800 mono text-[16px]">{toUserFormat(totalGOT).toFixed(2).replace(/\.00$/, '')}</td>
              <td className="p-2 text-teal-800 mono text-[16px]">{toUserFormat(totalEOT).toFixed(2).replace(/\.00$/, '')}</td>
            </tr>
          </tfoot>
        </table>
      </div>

      <div className="bg-white p-3.5 rounded-xl border border-slate-100 shadow-sm space-y-3">
        <div className="flex justify-between items-center px-1">
          <span className="text-slate-400 text-[12px] uppercase font-bold tracking-wider">Monthly Salary</span>
          <div className="flex items-center gap-1.5 font-mono text-[15px] font-bold text-slate-700">
            <span>{settings.salary.toLocaleString()}</span>
            <button onClick={() => setModal({ title: "Salary এডিট", text: "নতুন Salary দিন", value: settings.salary.toString(), type: "number", callback: (v) => saveSettings({ salary: parseFloat(v) }) })} className="text-teal-500 hover:text-teal-700 p-1">
              <Edit2 size={13} />
            </button>
          </div>
        </div>
        <div className="flex justify-between items-center px-1">
          <span className="text-slate-400 text-[12px] uppercase font-bold tracking-wider">Attendance Bonus</span>
          <div className="flex items-center gap-1.5 font-mono text-[15px] font-bold text-slate-700">
            <span>{effectiveBonus.toLocaleString()}</span>
            {absentDays === 0 && (
              <button onClick={() => setModal({ title: "Bonus এডিট", text: "নতুন Bonus দিন", value: (settings.bonus || 0).toString(), type: "number", callback: (v) => saveSettings({ bonus: parseFloat(v) }) })} className="text-teal-500 hover:text-teal-700 p-1">
                <Edit2 size={13} />
              </button>
            )}
          </div>
        </div>
        <div className="flex justify-between items-center px-1">
          <span className="text-slate-400 text-[12px] uppercase font-bold tracking-wider">Overtime Rate</span>
          <div className="flex items-center gap-1.5 font-mono text-[15px] font-bold text-slate-700">
            <span>{settings.rate}</span>
          </div>
        </div>
        <div className="flex justify-between items-center px-1 text-rose-700 bg-rose-50/10 py-1 rounded-lg">
          <div className="flex flex-col ml-1">
            <span className="text-[12px] uppercase font-bold tracking-wider">Absent ({absentDays} Days)</span>
            <span className="text-[9px] font-bold opacity-60">Rate: {Math.round(deductionPerDay)} / Day</span>
          </div>
          <div className="flex items-center gap-1.5 font-mono text-[15px] font-bold mr-1">
            <span>{totalDeduction.toLocaleString()}</span>
          </div>
        </div>
        <div className="flex justify-between items-center px-1 text-rose-700">
          <span className="text-[12px] uppercase font-bold tracking-wider ml-1">Advance</span>
          <div className="flex items-center gap-1.5 font-mono text-[15px] font-bold mr-1">
            <span>{settings.advance.toLocaleString()}</span>
            <button onClick={() => setModal({ title: "Advance এডিট", text: "নতুন Advance দিন", value: (settings.advance || 0).toString(), type: "number", callback: (v) => saveSettings({ advance: parseFloat(v) }) })} className="text-rose-400 hover:text-rose-600 p-1">
              <Edit2 size={13} />
            </button>
          </div>
        </div>
        <div className="flex justify-between items-center px-1 pt-2.5 border-t border-slate-50">
          <span className="text-slate-400 text-[13px] uppercase font-bold tracking-wider">OT Salary</span>
          <span className="font-mono text-[16px] font-black text-slate-700">{otSalary.toLocaleString()}</span>
        </div>
        
        <div className="grid grid-cols-2 gap-2 mt-2">
          <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-100 text-right shadow-sm transition-all active:scale-95 cursor-default">
            <p className="text-[12px] text-slate-400 font-bold uppercase mb-1 tracking-wide">Payslip</p>
            <p className="text-[20px] font-black text-slate-700 mono leading-none tracking-tight">৳{payslip.toLocaleString()}</p>
          </div>
          <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-100 text-right shadow-sm transition-all active:scale-95 cursor-default">
            <p className="text-[12px] text-slate-400 font-bold uppercase mb-1 tracking-wide">Extra Salary</p>
            <p className="text-[20px] font-black text-teal-600 mono leading-none tracking-tight">৳{extraSalary.toLocaleString()}</p>
          </div>
        </div>

        <div className="p-3 mt-1 bg-teal-600 rounded-xl shadow-xl shadow-teal-100 flex justify-between items-center ring-1 ring-white/20">
          <span className="text-teal-50 font-bold text-[13px] uppercase tracking-wide">Final Salary</span>
          <span className="text-white font-black text-xl mono tracking-tight">৳{finalSalary.toLocaleString()}</span>
        </div>
      </div>

      <div className="mt-4 flex gap-2">
        <button onClick={backupData} className="flex-1 border border-slate-200 text-slate-500 p-2 rounded-lg flex items-center justify-center gap-2 text-[10px] font-bold hover:bg-slate-50 transition active:scale-95">
          <Download size={12} /> Backup
        </button>
        <button onClick={() => document.getElementById('restore-input')?.click()} className="flex-1 border border-slate-200 text-slate-500 p-2 rounded-lg flex items-center justify-center gap-2 text-[10px] font-bold hover:bg-slate-50 transition active:scale-95">
          <Upload size={12} /> Restore
        </button>
        <input type="file" id="restore-input" className="hidden" accept=".json" onChange={handleRestore} />
      </div>

      <AnimatePresence>
        {showProfile && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="bg-white p-6 rounded-3xl max-w-sm w-full shadow-2xl relative"
            >
              <button onClick={() => setShowProfile(false)} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 font-bold">
                <X size={24} />
              </button>
              
              <div className="flex flex-col items-center mt-4">
                {user.photoURL ? (
                  <img src={user.photoURL} alt="Profile" className="w-20 h-20 rounded-full border-4 border-slate-50 shadow-md mb-4" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-20 h-20 rounded-full bg-teal-100 flex items-center justify-center text-teal-600 text-3xl font-bold border-4 border-slate-50 shadow-md mb-4">
                    {(user.displayName || user.email)?.charAt(0) || 'U'}
                  </div>
                )}
                <h3 className="text-xl font-black text-slate-800 uppercase">{user.displayName || 'User'}</h3>
                <p className="text-sm text-slate-500 mb-8">{user.email}</p>
                
                <div className="w-full space-y-3">
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 w-full">
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-1">Account info</p>
                    <p className="text-xs text-slate-600 font-medium italic">Joined via {user.providerData[0]?.providerId || 'Email'}</p>
                  </div>
                  
                  <button 
                    onClick={() => {
                      setShowProfile(false);
                      handleUpdatePassword();
                    }}
                    className="w-full flex items-center justify-center gap-2 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 py-4 rounded-2xl font-black text-sm uppercase tracking-wider transition-all active:scale-95 border border-emerald-100"
                  >
                    <Lock size={18} />
                    Change Password
                  </button>

                  <button 
                    onClick={() => {
                      setShowProfile(false);
                      handleDeleteAccount();
                    }}
                    className="w-full flex items-center justify-center gap-2 bg-rose-50 text-rose-600 hover:bg-rose-100 py-4 rounded-2xl font-black text-sm uppercase tracking-wider transition-all active:scale-95 border border-rose-100"
                  >
                    <Trash2 size={18} />
                    Delete My Account
                  </button>
                </div>
                
                <p className="text-[10px] text-slate-400 mt-8 text-center px-4 leading-relaxed">
                  Warning: Deleting your account will permanently remove all your overtime records and settings from our cloud database.
                </p>
              </div>
            </motion.div>
          </div>
        )}

        {showInfo && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="bg-white p-6 rounded-3xl max-w-sm w-full shadow-2xl relative"
            >
              <button onClick={() => setShowInfo(false)} className="absolute top-4 right-4 text-red-500 font-bold">
                <X size={24} />
              </button>
              <h3 className="text-lg font-bold mb-4">OT Manager Pro Info</h3>
              <div className="mb-4 pb-4 border-b border-slate-100">
                <p className="text-xs font-bold text-teal-600 uppercase tracking-wider mb-2">Developed By</p>
                <p className="text-sm font-black text-slate-800 mb-2">Hridoy Hasan Yeasin</p>
                <div className="space-y-1.5">
                  <a href="tel:01600180139" className="flex flex-col border-l-[3px] border-emerald-500 bg-emerald-50/60 p-2.5 rounded-xl hover:bg-emerald-100/80 transition-colors">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Phone</span>
                    <span className="text-xs text-slate-600 font-mono">01600180139</span>
                  </a>
                  <a href="mailto:hridoyeasin63@gmail.com" className="flex flex-col border-l-[3px] border-blue-500 bg-blue-50/60 p-2.5 rounded-xl hover:bg-blue-100/80 transition-colors">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Email</span>
                    <span className="text-xs text-slate-600 font-mono">hridoyeasin63@gmail.com</span>
                  </a>
                </div>
              </div>

              <div className="mb-4 pb-4 border-b border-slate-100">
                <p className="text-xs font-bold text-teal-600 uppercase tracking-wider mb-3">Social Connect</p>
                <div className="flex gap-4">
                  <a href="https://facebook.com/hridoyeasin63" target="_blank" rel="noopener noreferrer" className="p-2 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-600 hover:text-white transition-all shadow-sm group">
                    <Facebook size={20} />
                  </a>
                  <a href="https://wa.me/8801600180139" target="_blank" rel="noopener noreferrer" className="p-2 bg-emerald-50 text-emerald-600 rounded-xl hover:bg-emerald-600 hover:text-white transition-all shadow-sm">
                    <MessageCircle size={20} />
                  </a>
                  <a href="https://twitter.com/hridoyeasin63" target="_blank" rel="noopener noreferrer" className="p-2 bg-sky-50 text-sky-500 rounded-xl hover:bg-sky-500 hover:text-white transition-all shadow-sm">
                    <Twitter size={20} />
                  </a>
                </div>
              </div>

              <p className="text-xs text-slate-400 mb-4 italic">Version 1.0 - Cloud Sync Ready</p>
              <ul className="text-[11px] space-y-1.5 text-gray-600">
                <li>• ওটি ইনপুটে দশমিক ব্যবহার করা যাবে (যেমন ১.৩০ = ১ ঘন্টা ৩০ মিনিট)। ৬০ এর বেশি মিনিট হলে তা অটোমেটিক ঘন্টায় যোগ হবে (যেমন ২. ৯০ = ৩.৩০)।</li>
                <li>• ০০০ → অনুপস্থিত (Absent) হিসেবে সেট করতে</li>
                <li>• ০০০০ → ছুটির দিন (Holiday) হিসেবে সেট করতে</li>
                <li>• ওটি বা হলিডে মুছতে লং-প্রেস করুন (শুক্রবার ব্যাতীত)</li>
                <li>• অনুপস্থিতি থাকলে এটেন্ডেন্স বোনাস ০ হয়ে যাবে</li>
                <li>• শুক্রবার অটো ছুটির দিন</li>
                <li>• ডাটা অটোমেটিক ক্লাউডে সেভ হবে</li>
              </ul>


            </motion.div>
          </div>
        )}

        {modal && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="bg-white p-6 rounded-3xl max-w-xs w-full shadow-2xl"
            >
              <h3 className="text-lg font-bold mb-1">{modal.title}</h3>
              <p className="text-xs text-gray-500 mb-4">{modal.text}</p>
              {modal.type !== 'alert' && modal.type !== 'confirm' && (
                <input 
                  type={modal.type}
                  className="w-full p-3 border rounded-xl mb-4 font-bold"
                  defaultValue={modal.value}
                  id="modal-input"
                  autoFocus
                />
              )}
              <div className="flex gap-2">
                {modal.type !== 'alert' && <button onClick={() => setModal(null)} className="flex-1 bg-red-100 text-red-600 p-2 rounded-xl font-bold font-mono uppercase text-[10px] tracking-widest">Cancel</button>}
                <button 
                  onClick={() => {
                    const input = document.getElementById('modal-input') as HTMLInputElement;
                    const val = input?.value || "";
                    modal.callback(val);
                    setModal(prev => prev === modal ? null : prev);
                  }}
                  className="flex-1 bg-emerald-500 text-white p-2 rounded-xl font-bold font-mono uppercase text-[10px] tracking-widest"
                >
                  Confirm
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
